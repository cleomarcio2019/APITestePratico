package br.com.testepractico.api.cliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiClienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
