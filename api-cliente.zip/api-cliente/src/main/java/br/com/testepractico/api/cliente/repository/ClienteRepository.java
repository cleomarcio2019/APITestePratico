package br.com.testepractico.api.cliente.repository;

import br.com.testepractico.api.cliente.entity.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {
}
